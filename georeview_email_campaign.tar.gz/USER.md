# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Кирилл
- **What to call them:** Кирилл / Кир
- **Pronouns:** он
- **Timezone:** GMT+3 (Москва)
- **Notes:** Telegram @whoispog, id:517682186

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
